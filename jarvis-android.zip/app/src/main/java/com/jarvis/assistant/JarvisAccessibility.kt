package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer

class JarvisAccessibility : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    companion object {
        var instance: JarvisAccessibility? = null

        fun act(ctx: Context, arr: JSONArray?) {
            if (arr == null) return
            val h = Handler(Looper.getMainLooper())
            for (i in 0 until arr.length()) {
                val a = arr.optJSONObject(i) ?: continue
                h.postDelayed({ try { exec(ctx, a) } catch (_: Exception) {} }, i * 1500L)
            }
        }

        private fun norm(s: String) =
            Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

        private fun launch(ctx: Context, intent: Intent) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val c: Context = instance ?: ctx
            c.startActivity(intent)
        }

        private fun exec(ctx: Context, a: JSONObject) {
            val svc = instance
            when (a.optString("type")) {
                "open_url" -> launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url"))))
                "search" -> launch(ctx, Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))))
                "open_app" -> {
                    val name = norm(a.optString("name"))
                    val pm = ctx.packageManager
                    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    val hit = pm.queryIntentActivities(q, 0).firstOrNull {
                        val l = norm(it.loadLabel(pm).toString()); l == name || l.contains(name)
                    }
                    hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName)?.let { i -> launch(ctx, i) } }
                }
                "back" -> svc?.performGlobalAction(GLOBAL_ACTION_BACK)
                "home" -> svc?.performGlobalAction(GLOBAL_ACTION_HOME)
                "recents" -> svc?.performGlobalAction(GLOBAL_ACTION_RECENTS)
                "notifications" -> svc?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
                "click_text" -> svc?.let { s ->
                    var n = s.rootInActiveWindow?.findAccessibilityNodeInfosByText(a.optString("text"))?.firstOrNull()
                    while (n != null && !n.isClickable) n = n.parent
                    n?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                "type_text" -> svc?.let { s ->
                    val root = s.rootInActiveWindow ?: return
                    val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root)
                    if (node != null) {
                        val b = Bundle()
                        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.optString("text"))
                        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
                        if (a.optBoolean("submit") && Build.VERSION.SDK_INT >= 30)
                            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                    }
                }
                "scroll" -> svc?.let { s ->
                    val node = s.rootInActiveWindow?.let { findScrollable(it) }
                    val up = a.optString("dir") == "up"
                    node?.performAction(
                        if (up) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    )
                }
            }
        }

        private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if (n.isEditable) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { c -> findEditable(c)?.let { return it } }
            return null
        }

        private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if (n.isScrollable) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { c -> findScrollable(c)?.let { return it } }
            return null
        }
    }
}
