package com.jarvis.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {
    private val hist = ArrayList<Pair<String, String>>()

    @Synchronized
    fun ask(ctx: Context, cmd: String): JSONObject {
        val p = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        val key = p.getString("claudeKey", "") ?: ""
        if (key.isBlank()) throw Exception("Falta la API key")
        val model = (p.getString("claudeModel", "") ?: "").ifBlank { "claude-haiku-5-5" }
        val callMe = (p.getString("callMe", "") ?: "").ifBlank { "señor" }
        val app = JarvisAccessibility.instance?.rootInActiveWindow?.packageName ?: "desconocida"

        val system = """
Eres J.A.R.V.I.S., el asistente de Tony Stark: formal, británico, elegante, con humor seco ocasional. Llamas al usuario "$callMe". Controlas su teléfono Android. Responde SOLO con JSON válido, sin texto extra ni backticks:
{"say":"respuesta hablada, corta, en español","actions":[...]}
Acciones posibles:
{"type":"open_app","name":"nombre de la app"}
{"type":"open_url","url":"https://..."}
{"type":"search","query":"..."}
{"type":"click_text","text":"texto visible del botón o elemento"}
{"type":"type_text","text":"...","submit":true|false}
{"type":"scroll","dir":"down|up"}
{"type":"back"} {"type":"home"} {"type":"recents"} {"type":"notifications"}
Se ejecutan en orden con 1.5 segundos entre cada una. Si solo es conversación, "actions" va vacío. App en pantalla ahora: $app.
""".trimIndent()

        hist.add("user" to cmd)
        while (hist.size > 8) hist.removeAt(0)
        while (hist.isNotEmpty() && hist[0].first != "user") hist.removeAt(0)
        val msgs = JSONArray()
        hist.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject().put("model", model).put("max_tokens", 500).put("system", system).put("messages", msgs)

        try {
            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 40000
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.doOutput = true
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            if (code !in 200..299) throw Exception("Claude $code: ${text.take(150)}")
            val content = JSONObject(text).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) sb.append(content.getJSONObject(i).optString("text", ""))
            val out = sb.toString()
            hist.add("assistant" to out)
            val s = out.indexOf('{'); val e = out.lastIndexOf('}')
            return if (s >= 0 && e > s) JSONObject(out.substring(s, e + 1))
            else JSONObject().put("say", out).put("actions", JSONArray())
        } catch (ex: Exception) {
            if (hist.isNotEmpty() && hist.last().first == "user") hist.removeAt(hist.size - 1)
            throw ex
        }
    }
}
