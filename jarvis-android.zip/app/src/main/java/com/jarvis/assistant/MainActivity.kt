package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val inputs = LinkedHashMap<String, EditText>()
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 64) }
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0B1220")); addView(col) }

        col.addView(TextView(this).apply { text = "J.A.R.V.I.S."; textSize = 30f; setTextColor(Color.parseColor("#00B4FF")) })
        col.addView(TextView(this).apply {
            text = "Di \"Jarvis\" y dime qué hacer."; setTextColor(Color.parseColor("#9FB4D0")); setPadding(0, 0, 0, 24)
        })

        fun field(key: String, label: String, def: String, secret: Boolean = false) {
            col.addView(TextView(this).apply { text = label; setTextColor(Color.parseColor("#7FD8FF")); setPadding(0, 24, 0, 4) })
            val e = EditText(this).apply {
                setText(prefs.getString(key, def)); setTextColor(Color.WHITE); setSingleLine()
                if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            inputs[key] = e; col.addView(e)
        }
        fun button(text: String, onClick: () -> Unit) {
            col.addView(Button(this).apply { this.text = text; setOnClickListener { onClick() } })
        }

        field("claudeKey", "API key de Claude", "", true)
        field("claudeModel", "Modelo de Claude", "claude-haiku-5-5")
        field("fishKey", "API key de Fish Audio (opcional)", "", true)
        field("fishVoice", "ID de voz de Fish Audio (opcional)", "")
        field("fishModel", "Modelo de Fish Audio", "s1")
        field("callMe", "Cómo te llama", "señor")

        col.addView(View(this).apply { minimumHeight = 24 })
        button("1. Guardar ajustes") { save(); toast("Guardado") }
        button("2. Activar accesibilidad (para controlar apps)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button("3. ACTIVAR JARVIS") { start() }
        button("Detener JARVIS") {
            startService(Intent(this, JarvisService::class.java).setAction("STOP")); toast("Detenido")
        }
        button("Ajustes de batería (ponla sin restricciones)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        setContentView(scroll)
    }

    private fun save() {
        val ed = prefs.edit()
        inputs.forEach { (k, v) -> ed.putString(k, v.text.toString().trim()) }
        ed.apply()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun start() {
        save()
        if (prefs.getString("claudeKey", "").isNullOrBlank()) return toast("Falta la API key de Claude")
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else launch()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launch()
        else toast("Sin micrófono no puedo escucharte")
    }

    private fun launch() {
        startForegroundService(Intent(this, JarvisService::class.java))
        toast("JARVIS activado")
    }
}
