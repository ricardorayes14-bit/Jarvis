package com.jarvis.assistant

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class Voice(private val ctx: Context) : TextToSpeech.OnInitListener {
    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var tts: TextToSpeech? = TextToSpeech(ctx, this)

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) {
            tts?.language = Locale("es", "MX")
            tts?.setPitch(0.6f)
            tts?.setSpeechRate(0.95f)
        }
    }

    fun speak(text: String, done: () -> Unit) {
        if (text.isBlank()) { done(); return }
        val p = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        val key = p.getString("fishKey", "") ?: ""
        val voiceId = p.getString("fishVoice", "") ?: ""
        val model = (p.getString("fishModel", "") ?: "").ifBlank { "s1" }
        if (key.isNotBlank() && voiceId.isNotBlank()) {
            Thread {
                try {
                    val f = fish(text, key, voiceId, model)
                    main.post { play(f, text, done) }
                } catch (e: Exception) {
                    main.post { local(text, done, 0) }
                }
            }.start()
        } else local(text, done, 0)
    }

    private fun fish(text: String, key: String, voiceId: String, model: String): File {
        val c = URL("https://api.fish.audio/v1/tts").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 40000
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("model", model)
        c.doOutput = true
        val body = JSONObject().put("text", text).put("reference_id", voiceId).put("format", "mp3")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode != 200) throw Exception("Fish ${c.responseCode}")
        val f = File.createTempFile("fish", ".mp3", ctx.cacheDir)
        c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f
    }

    private fun play(f: File, text: String, done: () -> Unit) {
        val mp = MediaPlayer()
        try {
            mp.setDataSource(f.absolutePath)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { it.release(); f.delete(); done() }
            mp.setOnErrorListener { m, _, _ -> m.release(); local(text, done, 0); true }
            mp.prepareAsync()
        } catch (e: Exception) {
            mp.release(); local(text, done, 0)
        }
    }

    private fun local(text: String, done: () -> Unit, attempt: Int) {
        val t = tts
        if (t == null) { done(); return }
        if (!ready) {
            if (attempt < 10) main.postDelayed({ local(text, done, attempt + 1) }, 400) else done()
            return
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post(done) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post(done) }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    fun shutdown() {
        tts?.stop(); tts?.shutdown(); tts = null
    }
}
