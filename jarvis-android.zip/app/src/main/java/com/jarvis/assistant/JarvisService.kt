package com.jarvis.assistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class JarvisService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var running = false
    private var busy = false
    private var awakeUntil = 0L
    private lateinit var voice: Voice
    private val wake = Regex("\\b(jarvis|yarvis|jarbis|harvis|yarbis|jarvi|yervis|jarvins)\\b", RegexOption.IGNORE_CASE)

    private val callMe: String
        get() = getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("callMe", "señor")
            ?.ifBlank { "señor" } ?: "señor"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        voice = Voice(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            running = false
            rec?.destroy()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (!running) {
            running = true
            say("Sistemas en línea. A sus órdenes, $callMe.")
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "JARVIS", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, JarvisService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("JARVIS activo")
            .setContentText("Di \"Jarvis\" para darme una orden")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Detener", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun say(text: String) {
        busy = true
        rec?.cancel()
        voice.speak(text) { busy = false; listen() }
    }

    private fun listen() {
        if (!running || busy) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) heard(t.trim())
                    if (!busy) main.postDelayed({ listen() }, 200)
                }
                override fun onError(error: Int) {
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { running = false; return }
                    val wait = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                        error == SpeechRecognizer.ERROR_TOO_MANY_REQUESTS) 1500L else 300L
                    if (!busy) main.postDelayed({ listen() }, wait)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            r.startListening(i)
        }
    }

    private fun heard(text: String) {
        if (busy) return
        val m = wake.find(text)
        if (m != null) {
            val cmd = text.substring(m.range.last + 1).trim().trimStart(',', '.', ':', ';', '¡', '!', '¿', '?', ' ')
            if (cmd.isNotEmpty()) return runCommand(cmd)
            awakeUntil = System.currentTimeMillis() + 10_000
            return say("Dígame, $callMe.")
        }
        if (System.currentTimeMillis() < awakeUntil) {
            awakeUntil = 0
            runCommand(text)
        }
    }

    private fun runCommand(cmd: String) {
        busy = true
        rec?.cancel()
        Thread {
            try {
                val r = Brain.ask(this, cmd)
                val say = r.optString("say", "")
                main.post {
                    JarvisAccessibility.act(this, r.optJSONArray("actions"))
                    voice.speak(say) { busy = false; listen() }
                }
            } catch (e: Exception) {
                main.post { voice.speak("Tuve un problema, $callMe.") { busy = false; listen() } }
            }
        }.start()
    }

    override fun onDestroy() {
        running = false
        rec?.destroy()
        voice.shutdown()
        super.onDestroy()
    }
}
