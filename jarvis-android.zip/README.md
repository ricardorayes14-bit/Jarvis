# JARVIS para Android

## Opción A: sin instalar nada (GitHub)
1. Crea una cuenta en github.com y un repositorio nuevo.
2. Sube TODO el contenido de esta carpeta (incluida la carpeta oculta .github).
3. Ve a la pestaña Actions > "Build APK" > Run workflow. Espera 3-5 min.
4. Entra a la ejecución terminada, descarga "jarvis-apk", descomprime e instala app-debug.apk.

## Opción B: Android Studio
Abre esta carpeta con Android Studio, espera el sync y pulsa Build > Build APK(s).

## En el celular
1. Instala el APK (permite "instalar apps desconocidas").
2. Si Android bloquea la accesibilidad: Ajustes > Apps > JARVIS > menú ⋮ > "Permitir ajustes restringidos".
3. Abre JARVIS, pon tu API key de Claude (y Fish Audio si quieres), guarda.
4. Botón 2: activa JARVIS en Accesibilidad. Botón 3: ACTIVAR JARVIS.
5. Pon la batería de JARVIS en "Sin restricciones".
